# Imperial_discord_bot
Imperial Discord Bot

# Todo
- [x] Keep a list of members and their ranks
- [x] Connect Minecraft account to a member.
- [x] Show member Info. 
- [ ] Custom prefix for server
- [ ] Server Info
- [ ] Economy
- [ ] Anouncments
- [ ] Sync if is member between discord servers
- [x]  Enemy's list