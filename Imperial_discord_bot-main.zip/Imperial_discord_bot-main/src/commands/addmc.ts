import * as framework from 'advanced-command-handler'
import fetch from 'node-fetch'
import { connect } from '../mongo.js'

export default new framework.Command(
    {
        name: 'Add minecraft account',
        description: 'Add your minecraft account to your profile',
        usage : 'You need to connect with minecraft to  srv.mc-oauth.net than run the command again with !addmc <token>', 
    },
    async (handler, message, args) => {
        if (!args[0]) {
            message.channel.send('You need to go "srv.mc-oauth.net"  than run the command again with !addmc <token>')
        }
        else {
            fetch('https://mc-oauth.net/api/api?token', {
                method: "GET",
                headers: {
                    "token": args[0]
                }
            }).then(res => res.json()).then(json => {
                if (json !== 'fail') {
                    connect()
                    const result = userSchema.findOne({
                        'minecraft.username': json.username
                    })
                    if (result === null) {
                        userSchema.findOneAndUpdate({
                            discordId: message.author.id,
                            },
                            {
                                minecraft: [{
                                    username: json.username,
                                    uuid: json.uuid
                                }]
                            });
                        message.channel.send('Account sucesfuly added')
                    }
                    else{
                        message.channel.send('This account is already added to another account')
                    }
                }
            });
        }
    }
)