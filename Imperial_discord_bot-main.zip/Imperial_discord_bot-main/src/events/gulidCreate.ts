import * as framework from 'advanced-command-handler'
import { connect } from '../mongo.js'
import gulidSchema from '../schemas/gulid'
module.exports = new framework.Event(
	{
		name: 'guildCreate',
	},
	async (handler, gulid) => {
        connect()
        const gulidDb = await gulidSchema.findOne({
            gulidId :  gulid.id,
        })
		if(gulidDb === null){
			await new gulidSchema({
				gulidId : gulid.id,
				isBranch : false,
				setup : false, 
			})
		}
        
	}
);