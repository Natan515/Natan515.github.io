import * as framework from 'advanced-command-handler'
import { connect } from '../mongo.js'
import userSchema from '../schemas/user'
import gulidSchema from '../schemas/gulid'
module.exports = new framework.Event(
	{
		name: 'guildMemberUpdate',
	},
	async (handler, oldMember, newMember) => {
		connect()
		const gulid = gulidSchema.findOne({
			gulidId: newMember.gulid.id,
		})
		if (gulid.setup === true) {
			const user = userSchema.findOne({
				discordId: newMember.id,
			})
			if (user !== null) {
				newMember.roles.cache.forEach(element => {
					gulid.ranks.forEach(userRank => {
						if (ranks.id === element.id) {
							gulidSchema.findOneAndUpdate({
								gulidId: newMember.gulid.id,
							}, {
								$push: {
									branch: {
										name: gulid.name,
										rank: userRank.level,
									},
								},
							});
						}
					})
				});
			}
		}
	}
);