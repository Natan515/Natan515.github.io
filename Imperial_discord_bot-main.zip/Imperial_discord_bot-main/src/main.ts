import * as framework from 'advanced-command-handler'
require('dotenv').config({path: '../.env'})

framework.CommandHandler.create({
    owners : ["403941520048390145", "585885762562686976"], //brickzebra, cristiioan
    prefixes: ['!'],
	commandsDir: 'commands',
	eventsDir: 'events'
})

framework.CommandHandler.launch({
    token : "${process.env.TOKEN}"
})
