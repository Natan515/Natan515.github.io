import mongoose from 'mongoose'
const reqString = {
    type: String,
    required: true,
}
const reqNumber = {
    type: Number,
    required: true,
}
const reqBool = {
    default : false,
    type: Boolean,
    required: true,
}
const rankSchema = new mongoose.Schema({
    id : reqNumber,
    level : reqNumber,
})
const gulidSchema = new mongoose.Schema(
    {
        gulidId: reqNumber,
        name: String,
        isBranch: reqBool,
        setup : reqBool,
        rank : [rankSchema]
    },
    {
        timestamps: true,
    }
)

export default mongoose.model('gulids', gulidSchema)