import mongoose from 'mongoose'

const reqString = {
  type: String,
  required: true,
}
const reqNumber = {
  type: Number,
  required: true,
}
const reqBool = {
  type: Boolean,
  required: true,
}

const MinecraftSchema = new mongoose.Schema(
  {
    username: reqString,
    uuid: reqNumber
  },
  {
    timestamps: true,
  }
)
const BranchSchema = new mongoose.Schema(
  {
    BranchName: reqString,
    rank: reqNumber,
  },
  {
    timestamps: true,
  }
)

const userSchema = new mongoose.Schema(
  {
    discordId: reqNumber,
    status: reqNumber, // enemy : -1, not member : 0, member : 1
    minecraft: [MinecraftSchema],
    branch: []
  },
  {
    timestamps: true,
  }
)

export default mongoose.model('users', userSchema)